export default function AdminDashBoard(){
    return (
	<div>
	    <h1>Witaj w panelu admina!</h1>

	</div>
    );
}
