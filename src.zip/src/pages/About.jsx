function About(){
    return(
	<>
	    <div>
		<h1>About Page</h1>
		<p>To jest strona o nas</p>
	    </div>
	</>
    );
}

export default About;
