function Home(){
    
    return(
    <>
	<div>
	    <h1>Home Page</h1>
	    <p>To jest strona główna</p>
	</div>

    </>
    );
}

export default Home;
