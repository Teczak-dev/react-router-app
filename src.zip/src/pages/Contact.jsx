function Contact(){

    return(
	<>
	    <div>
		<h1>Contact Page</h1>
		<p>Contact: xxx-xxx-xxx</p>
	    </div>
	</>
    );

}

export default Contact;
