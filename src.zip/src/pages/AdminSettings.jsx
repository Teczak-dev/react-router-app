export default function AdminSettings(){
    return (
	<div>
	    <h1>Admin Settings</h1>
	    <form>
		<input type="checkbox"/>Włącz powiadomienia<br/>
		<input type="checkbox"/>Włącz dźwięk<br/>
	    </form>
	</div>
    );
}
